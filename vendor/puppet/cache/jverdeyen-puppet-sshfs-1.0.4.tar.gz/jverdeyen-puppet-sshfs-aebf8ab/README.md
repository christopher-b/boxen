# OSXFuse sshfs Puppet Module for Boxen

Install the latest version of [sshfs](https://github.com/osxfuse/sshfs), a file system based on the SSH File Transfer Protocol.

## Usage

```puppet
include sshfs
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.